News Downloader
==============

Search Google News and download the results to a CSV.

Intended to be combined with Mechanical Turk as part of a press campaign. [Full instructions here](http://wp.me/p2pmCq-gA).

#### [Demo](http://press.CustomerDevLabs.com)
