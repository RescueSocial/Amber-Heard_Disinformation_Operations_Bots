Folder Containing The Top UserFollower and Friend relationship
