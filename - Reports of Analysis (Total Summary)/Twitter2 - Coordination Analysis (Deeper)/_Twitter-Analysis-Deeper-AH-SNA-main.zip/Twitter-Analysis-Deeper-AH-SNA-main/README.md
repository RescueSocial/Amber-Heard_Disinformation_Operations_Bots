# Twitter-Analysis-Deeper-AH-SNA
Twitter Deeper Analysis by Researchers, Data Analysts, and Machine Learning on the Disinformation/Influence Operation against Amber Heard. - E.g., on Profiles, Coordinated Inauthentic Activity, Cluster Networks, Harms/Risks, Investigations, and Evidence.
https://www.sciencedirect.com/science/article/pii/S1751157720306386

Data, Code, Python Notebooks, Reports, can be added here.
